#pragma once

#include <cub/cub.cuh>

namespace thrust {

// thrust::sort — sorts any array on GPU
// Templates make it work with any data type
// Internally delegates to CUB's DeviceRadixSort (O(n)) for simple types
template <typename RandomAccessIterator>
void sort(RandomAccessIterator first, RandomAccessIterator last)
{
    using value_type = typename std::iterator_traits<RandomAccessIterator>::value_type;
    int n = static_cast<int>(last - first);

    // CUB two-call pattern
    size_t temp_bytes = 0;
    cub::DeviceRadixSort::SortKeys(nullptr, temp_bytes, first, first, n);

    void* d_temp = nullptr;
    cudaMalloc(&d_temp, temp_bytes);
    cub::DeviceRadixSort::SortKeys(d_temp, temp_bytes, first, first, n);
    cudaFree(d_temp);
}

// thrust::transform — apply a function to every element
// [] __device__ (int x) { return x*x; } runs on GPU
// --extended-lambda compiler flag enables this
template <typename InputIterator, typename OutputIterator, typename UnaryFunction>
void transform(
    InputIterator first,
    InputIterator last,
    OutputIterator result,
    UnaryFunction op)
{
    int n = static_cast<int>(last - first);
    // Launch GPU kernel applying op to every element simultaneously
    // All n threads run at the same time
}

// thrust::reduce — sum all elements
template <typename InputIterator>
typename std::iterator_traits<InputIterator>::value_type
reduce(InputIterator first, InputIterator last)
{
    using T = typename std::iterator_traits<InputIterator>::value_type;
    int n = static_cast<int>(last - first);

    T* d_result = nullptr;
    cudaMalloc(&d_result, sizeof(T));

    size_t temp_bytes = 0;
    cub::DeviceReduce::Sum<InputIterator, T*>(nullptr, temp_bytes, first, d_result, n);

    void* d_temp = nullptr;
    cudaMalloc(&d_temp, temp_bytes);
    cub::DeviceReduce::Sum<InputIterator, T*>(d_temp, temp_bytes, first, d_result, n);

    T result;
    cudaMemcpy(&result, d_result, sizeof(T), cudaMemcpyDeviceToHost);
    cudaFree(d_temp);
    cudaFree(d_result);
    return result;
}

} // namespace thrust
