# cmake/CUDAArchitectures.cmake
# Validates GPU architecture targets
# Include guard prevents double-processing

if(DEFINED CCCL_CUDA_ARCHITECTURES_INCLUDED)
    return()
endif()
set(CCCL_CUDA_ARCHITECTURES_INCLUDED TRUE)

set(CCCL_ALL_ARCHITECTURES 70 75 80 86 89 90)

function(cccl_validate_cuda_arch arch)
    list(FIND CCCL_ALL_ARCHITECTURES ${arch} idx)
    if(idx EQUAL -1)
        message(FATAL_ERROR
            "Unsupported CUDA architecture: sm_${arch}\n"
            "Supported: ${CCCL_ALL_ARCHITECTURES}\n"
        )
    endif()
endfunction()

function(cccl_set_cuda_architectures)
    if(NOT DEFINED CMAKE_CUDA_ARCHITECTURES)
        set(CMAKE_CUDA_ARCHITECTURES ${CCCL_ALL_ARCHITECTURES} PARENT_SCOPE)
    endif()
    foreach(arch IN LISTS CMAKE_CUDA_ARCHITECTURES)
        cccl_validate_cuda_arch(${arch})
    endforeach()
    message(STATUS "CCCL: Building for: ${CMAKE_CUDA_ARCHITECTURES}")
endfunction()
