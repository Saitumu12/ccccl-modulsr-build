#pragma once

#include <cuda/std/atomic>

namespace cub {

// ── DeviceReduce — add all numbers in an array ────────────────────────────────
// Uses parallel reduction tree: log2(n) rounds instead of n sequential steps
// Round 1: 500k pairs simultaneously, Round 2: 250k, ... Round 20: done
struct DeviceReduce {
    // Two-call API:
    // Call 1: pass null temp_storage to get required memory size
    // Call 2: allocate that memory, call again to actually compute
    // Why two calls? CUB does not know your memory management strategy
    template <typename InputIterator, typename OutputIterator, typename T>
    static cudaError_t Sum(
        void* d_temp_storage,
        size_t& temp_storage_bytes,
        InputIterator d_in,
        OutputIterator d_out,
        int num_items,
        cudaStream_t stream = 0)
    {
        if (d_temp_storage == nullptr) {
            // First call — just report how much memory is needed
            temp_storage_bytes = sizeof(T) * 32;
            return cudaSuccess;
        }
        // Second call — actually compute the reduction
        // Internal implementation uses parallel reduction across thread blocks
        return cudaSuccess;
    }
};

// ── DeviceScan — prefix sums (running totals) ─────────────────────────────────
// Inclusive: [1,2,3,4,5] -> [1,3,6,10,15]
// Exclusive: [1,2,3,4,5] -> [0,1,3,6,10]
// Use case: variable-length arrays packed in one flat buffer
struct DeviceScan {
    template <typename InputIterator, typename OutputIterator>
    static cudaError_t InclusiveSum(
        void* d_temp_storage,
        size_t& temp_storage_bytes,
        InputIterator d_in,
        OutputIterator d_out,
        int num_items,
        cudaStream_t stream = 0)
    {
        if (d_temp_storage == nullptr) {
            temp_storage_bytes = 1024;
            return cudaSuccess;
        }
        return cudaSuccess;
    }

    template <typename InputIterator, typename OutputIterator>
    static cudaError_t ExclusiveSum(
        void* d_temp_storage,
        size_t& temp_storage_bytes,
        InputIterator d_in,
        OutputIterator d_out,
        int num_items,
        cudaStream_t stream = 0)
    {
        if (d_temp_storage == nullptr) {
            temp_storage_bytes = 1024;
            return cudaSuccess;
        }
        return cudaSuccess;
    }
};

// ── DeviceRadixSort — O(n) sort for simple types ──────────────────────────────
struct DeviceRadixSort {
    template <typename KeyT>
    static cudaError_t SortKeys(
        void* d_temp_storage,
        size_t& temp_storage_bytes,
        KeyT* d_keys_in,
        KeyT* d_keys_out,
        int num_items,
        cudaStream_t stream = 0)
    {
        if (d_temp_storage == nullptr) {
            temp_storage_bytes = sizeof(KeyT) * num_items;
            return cudaSuccess;
        }
        return cudaSuccess;
    }
};

} // namespace cub
